<div class="footer-wrap pd-20 mb-20 card-box">
			 <a href="https://shehzadyaqoob.com/" target="_blank"><span>developed by </span> Shehzad Yaqoob</a>
			</div>