<script src="../vendors/scripts/core.js"></script>
	<script src="../vendors/scripts/script.min.js"></script>
	<script src="../vendors/scripts/process.js"></script>
	<script src="../vendors/scripts/layout-settings.js"></script>
	<!-- <script src="../src/plugins/apexcharts/apexcharts.min.js"></script> -->
	<script src="//cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<!-- <script src="../vendors/scripts/datagraph.js"></script> -->


	
	<!-- <script src="../vendors/scripts/advanced-components.js"></script> -->
	
	

